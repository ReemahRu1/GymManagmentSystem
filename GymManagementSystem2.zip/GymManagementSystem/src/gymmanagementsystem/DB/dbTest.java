/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gymmanagementsystem.DB;

import gymmanagementsystem.GymClasses.Admin;
import gymmanagementsystem.GymClasses.Classes;
import gymmanagementsystem.GymClasses.Feedback;
import gymmanagementsystem.GymClasses.Member;
import gymmanagementsystem.GymClasses.Service;
import gymmanagementsystem.GymClasses.Trainer;
import gymmanagementsystem.GymClasses.User;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ralru
 */
public class dbTest {
    public static void main(String[] args) throws SQLException {
      //Member m1 = new Member(61,"Haya","0123456781","reema1","1234","haya@gmail","6month");
       // Admin a1 = new Admin(0,"lama","0123456541","soso1","111","lama52@gmail");
      //Trainer t4 = new Trainer(21,null,null,null,null,null,null);
      // System.out.println(DatabaseHandler.insertAdmin(a1));
        //Classes c1 = new Classes(0,"monday","3:10","yoga","ssacm wk ",14,t4,"a12");
        //Feedback f = new Feedback(0,m1,t4,"work");
        //Service s = new Service(0,"fitnessEval",50);
        //User u;
        //u = m1;
        //Trainer t = new Trainer(21,"layla","1234567890","layla3","111","q@gmail.com","3-7");
       // Trainer t2 = new Trainer(42,"hajar","1234567890","h32","111","he@gmail.com","3-7");
        //User u = new Member (1,"Haya","0123456781","haya11","1234","sara52@gmail","6month");
       // System.out.println(DatabaseHandler.insertMemberService(new Member(1,"sara","0123456781","sara728","sa12352","sara52@gmail","6month"),new Service(1,"fitnessEval",50)));
       //System.out.println(DatabaseHandler.loadAll("Trainer"));
     // System.out.println(DatabaseHandler.getMemberById(61));
      // System.out.println(DatabaseHandler.getFeedbackForMemberById(61));
     // List<Feedback> feedbackList = DatabaseHandler.loadFeedbackByMemberId(61); 
     // for (Feedback f : feedbackList) {
    //System.out.println(f);  // This will print the `toString()` representation of each `Classes` object
  //}
    //System.out.println(DatabaseHandler.loadMemberUsernamesByRole());
     //System.out.println(DatabaseHandler.updateTrainer(t));
     //System.out.println(DatabaseHandler.insertMemberClasses(61, 21));
     
    }
}
